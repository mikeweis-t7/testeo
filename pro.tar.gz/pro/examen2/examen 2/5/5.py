import sqlite3  # importar el mod sqliot3

def create_database():
    conn = sqlite3.connect('example.db') # conectando o creando
    c = conn.cursor()   # crear cursor para ejecutar consultas

    # crea la tabla prudcuts si o exioste cotre columnas o campos
    c.execute('''CREATE TABLE IF NOT EXISTS products
                 (id INTEGER PRIMARY KEY, name TEXT, price REAL)''')
    # Insertar datos de ejemplo
    products = [
        ('Producto1', 10.0),
        ('Producto2', 20.0),
        ('Producto3', 30.0),
        ('Producto4', 25.0),
        ('Producto5', 15.0)
    ]
    c.executemany("INSERT INTO products (name, price) VALUES (?, ?)", products)
    conn.commit() # confirmar los cam,ìos
    conn.close()    # crara db

def search_products(comparison, price):
    conn = sqlite3.connect('example.db') # conectar
    c = conn.cursor() # crear un cursor para ejecutar consultas sql
    query = f"SELECT * FROM products WHERE price {comparison} ?"    # construir la consulta
    c.execute(query, (price,))  # ejecutar la conulta
    results = c.fetchall() # obtener todos los resultados
    conn.close() # finalizar la conexion
    return results  # return resiltadops de la consulta

def main():
    create_database()   # llama a la funcion para  crea la db

    # solicitar datos
    comparison = input("Ingrese el tipo de comparación (<, >, =): ")
    price = float(input("Ingrese el precio para comparar: "))

    # llarma a la funcion para buscar productos serfun la comparacion y el preio inghresaodo
    results = search_products(comparison, price)

    # imprimir los resultados enconterados
    print(f"Productos con precio {comparison} {price}:")
    for row in results:
        print(row)

if __name__ == "__main__":
    main()
