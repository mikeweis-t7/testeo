# pip install anytree

from anytree import Node, RenderTree

# nos basaremos en un arbol para crear el arbol genealogico

# Crear nodos para cada miembro de la familia
abuelo = Node("Abuelo") # Nodo raiz
abuela = Node("Abuela")
padre = Node("Padre", parent=abuelo)    # hijos de abuelo
madre = Node("Madre", parent=abuela)    # hujos de abuelo
tio = Node("Tío", parent=abuelo)
tia = Node("Tía", parent=abuela)
yo = Node("Yo", parent=padre)
hermano = Node("Hermano", parent=padre)
primo = Node("Primo", parent=tio)

# Renderizar el arbol genealogico
for pre, fill, node in RenderTree(abuelo):
    print("%s%s" % (pre, node.name))
