import random
import datetime

class Chromosome:
    def __init__(self, genes, fitness):
        self.Genes = genes
        self.Fitness = fitness

def _generate_parent(length, geneSet, get_fitness):
    genes = []
    while len(genes) < length:
        sampleSize = min(length - len(genes), len(geneSet))
        genes.extend(random.sample(geneSet, sampleSize))
    fitness = get_fitness(genes)
    return Chromosome(genes, fitness)

def _mutate(parent, geneSet, get_fitness):
    childGenes = parent.Genes[:]
    index = random.randrange(0, len(parent.Genes))
    newGene, alternate = random.sample(geneSet, 2)
    childGenes[index] = alternate if newGene == childGenes[index] else newGene
    fitness = get_fitness(childGenes)
    return Chromosome(childGenes, fitness)

def get_best(get_fitness, targetLen, optimalFitness, geneSet, display, custom_mutate=None, custom_create=None):
    random.seed()
    startTime = datetime.datetime.now()

    def fnMutate(parent):
        return _mutate(parent, geneSet, get_fitness)

    def fnGenerateParent():
        return _generate_parent(targetLen, geneSet, get_fitness)

    def fnCreate():
        if custom_create:
            genes = custom_create()
        else:
            genes = fnGenerateParent().Genes
        return genes

    optimalFitness = Chromosome([], optimalFitness)
    bestParent = fnGenerateParent()
    display(bestParent, startTime)

    while True:
        child = fnMutate(bestParent)
        if bestParent.Fitness > child.Fitness:
            continue
        display(child, startTime)
        if not optimalFitness.Fitness > child.Fitness:
            return child
