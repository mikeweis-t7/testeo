import math

class SimuladoRecozido:
    def __init__(self, solucion_inicial, temperatura_inicial, tasa_enfriamiento):
        self.solucion_actual = solucion_inicial
        self.temperatura = temperatura_inicial
        self.tasa_enfriamiento = tasa_enfriamiento

    def generar_vecino(self, solucion):
        vecino = solucion[:]
        i = random.randint(0, len(solucion) - 1)
        j = random.randint(0, len(solucion) - 1)
        vecino[i], vecino[j] = vecino[j], vecino[i]
        return vecino

    def evaluar(self, solucion):
        return sum(solucion)

    def aceptar(self, delta):
        if delta < 0:
            return True
        else:
            probabilidad = math.exp(-delta / self.temperatura)
            return random.random() < probabilidad

    def optimizar(self):
        while self.temperatura > 1:
            vecino = self.generar_vecino(self.solucion_actual)
            delta = self.evaluar(vecino) - self.evaluar(self.solucion_actual)
            if self.aceptar(delta):
                self.solucion_actual = vecino
            self.temperatura *= self.tasa_enfriamiento
        return self.solucion_actual

# Ejemplo de uso
solucion_inicial = [5, 3, 1, 2, 4]
simulado = SimuladoRecozido(solucion_inicial, temperatura_inicial=1000, tasa_enfriamiento=0.99)
optimo = simulado.optimizar()
print("Solución óptima:", optimo)
