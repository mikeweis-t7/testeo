"""
import math

# Clase para generar números pseudoaleatorios
class MiRandom:
    def __init__(self, semilla):
        self.semilla = semilla

    def randint(self, a, b):
        self.semilla = (self.semilla * 9301 + 49297) % 233280
        random_number = self.semilla / 233280.0  # Escalar la semilla a un número entre 0 y 1
        return a + int(random_number * (b - a + 1))

# Función de activación Softmax
def softmax(z):
    exp_z = [(2.71) ** i for i in z]
    sum_exp_z = sum(exp_z)
    return [i / sum_exp_z for i in exp_z]

# Clase para manejar vectores
class MiVector:
    def __init__(self, datos):
        self.datos = datos

    def __add__(self, otro):
        return MiVector([x + y for x, y in zip(self.datos, otro.datos)])

    def __mul__(self, otro):
        return MiVector([x * y for x, y in zip(self.datos, otro.datos)])

    def suma(self):
        return sum(self.datos)

    def dot(self, otro):
        return sum(x * y for x, y in zip(self.datos, otro.datos))

# Función para calcular el logaritmo natural mediante la serie de Taylor
def ln_taylor(x, n_terms=100):
    if x <= 0:
        raise ValueError("El logaritmo natural no está definido para valores no positivos.")
    if x == 1:
        return 0

    num = x - 1
    denom = x + 1
    y = num / denom

    ln_approx = 0
    for n in range(n_terms):
        term = (2 / (2 * n + 1)) * (y ** (2 * n + 1))
        ln_approx += term

    return 2 * ln_approx

# Función para calcular el logaritmo en base 10 usando el logaritmo natural
def log10_taylor(x):
    ln_10 = ln_taylor(10)
    ln_x = ln_taylor(x)
    return ln_x / ln_10

# Clase de la Red Neuronal con 3 capas
class RedNeuronal:
    def __init__(self, tasa_aprendizaje):
        self.tasa_aprendizaje = tasa_aprendizaje
        self.aleatorio = MiRandom(123)
        # Pesos para la capa de entrada a la capa oculta
        self.pesos_oculta = [MiVector([0.1 * self.aleatorio_value(), -0.2 * self.aleatorio_value(), 0.3 * self.aleatorio_value(), -0.4 * self.aleatorio_value()]) for _ in range(4)]
        self.sesgos_oculta = [0.1 * self.aleatorio_value() for _ in range(4)]
        # Pesos para la capa oculta a la capa de salida (3 clases)
        self.pesos_salida = [MiVector([0.1 * self.aleatorio_value(), -0.2 * self.aleatorio_value(), 0.3 * self.aleatorio_value()]) for _ in range(3)]
        self.sesgos_salida = [0.1 * self.aleatorio_value() for _ in range(3)]

    def aleatorio_value(self):
        return (self.aleatorio.randint(0, 100) - 50) / 100.0

    def entrenar(self, entradas, salidas_esperadas, epocas):
        for epoca in range(epocas):
            total_loss = 0
            for x, y_esperado in zip(entradas, salidas_esperadas):
                # Capa de entrada
                x_vec = MiVector(x)
                
                # Propagación hacia la capa oculta
                z_oculta = [x_vec.dot(self.pesos_oculta[i]) + self.sesgos_oculta[i] for i in range(4)]
                a_oculta = [math.tanh(z) for z in z_oculta]
                
                # Propagación hacia la capa de salida
                z_salida = [MiVector(a_oculta).dot(self.pesos_salida[i]) + self.sesgos_salida[i] for i in range(3)]
                y_predicho = softmax(z_salida)
                
                # Calcular la pérdida (entropía cruzada)
                loss = -sum(y_esperado[i] * math.log(y_predicho[i] + 1e-9) for i in range(3))
                total_loss += loss
                
                # Retropropagación y actualización de pesos y sesgos
                # Gradiente para la capa de salida
                gradientes_salida = [y_predicho[i] - y_esperado[i] for i in range(3)]
                
                # Actualización de pesos y sesgos para la capa de salida
                for i in range(3):
                    self.pesos_salida[i] = self.pesos_salida[i] - MiVector(a_oculta) * MiVector([gradientes_salida[i] * self.tasa_aprendizaje] * 4)
                    self.sesgos_salida[i] -= gradientes_salida[i] * self.tasa_aprendizaje
                
                # Gradiente para la capa oculta
                gradientes_oculta = [sum(self.pesos_salida[i].datos[j] * gradientes_salida[i] * (1 - a_oculta[j]**2) for i in range(3)) for j in range(4)]
                
                # Actualización de pesos y sesgos para la capa oculta
                for i in range(4):
                    self.pesos_oculta[i] = self.pesos_oculta[i] - x_vec * gradientes_oculta[i] * self.tasa_aprendizaje
                    self.sesgos_oculta[i] -= gradientes_oculta[i] * self.tasa_aprendizaje
            
            # Imprimir la pérdida en cada época
            if epoca % 100 == 0:
                print(f"Epoca {epoca + 1}/{epocas}, Pérdida: {total_loss / len(entradas):.4f}")

    def predecir(self, x):
        # Propagación hacia la capa oculta
        x_vec = MiVector(x)
        z_oculta = [x_vec.dot(self.pesos_oculta[i]) + self.sesgos_oculta[i] for i in range(4)]
        a_oculta = [math.tanh(z) for z in z_oculta]
        
        # Propagación hacia la capa de salida
        z_salida = [MiVector(a_oculta).dot(self.pesos_salida[i]) + self.sesgos_salida[i] for i in range(3)]
        y_predicho = softmax(z_salida)
        
        return y_predicho

if __name__ == "__main__":
    # Datos de entrenamiento (con todas las características)
    entradas = [
        [5.1, 3.5, 1.4, 0.2],  # Iris-setosa
        [4.9, 3.0, 1.4, 0.2],  # Iris-setosa
        [6.2, 3.4, 5.4, 2.3],  # Iris-virginica
        [5.9, 3.0, 5.1, 1.8],  # Iris-virginica
        [7.0, 3.2, 4.7, 1.4],  # Iris-versicolor
        [6.4, 3.2, 4.5, 1.5]   # Iris-versicolor
    ]
    salidas = [
        [1, 0, 0],  # Iris-setosa
        [1, 0, 0],  # Iris-setosa
        [0, 0, 1],  # Iris-virginica
        [0, 0, 1],  # Iris-virginica
        [0, 1, 0],  # Iris-versicolor
        [0, 1, 0]   # Iris-versicolor
    ]
    
    red = RedNeuronal(tasa_aprendizaje=0.2)  # Tasa de aprendizaje
    red.entrenar(entradas, salidas, epocas=2000)  # Número de épocas

    # Prueba de predicción
    nuevas_entradas = [
        [4.8, 3.4, 1.6, 0.2],    # Iris-setosa
        [7.0, 3.2, 4.7, 1.4],    # Iris-versicolor
        [6.8, 3.0, 5.5, 2.1]     # Iris-virginica
    ]
    
    print("Predicciones:")
    for entrada in nuevas_entradas:
        prediccion = red.predecir(entrada)
        clases = ["Iris-setosa", "Iris-versicolor", "Iris-virginica"]
        clase_predicha = clases[prediccion.index(max(prediccion))]
        print(f"Entrada: {entrada} -> Predicción: {clase_predicha}")
"""

import math

# Clase para generar números pseudoaleatorios
class MiRandom:
    def __init__(self, semilla):
        self.semilla = semilla

    def randint(self, a, b):
        self.semilla = (self.semilla * 9301 + 49297) % 233280
        random_number = self.semilla / 233280.0  # Escalar la semilla a un número entre 0 y 1
        return a + int(random_number * (b - a + 1))

# Función de activación Sigmoid
def sigmoid(z):
    return 1 / (1 + math.exp(-z))

# Función de activación Softmax
def softmax(z):
    exp_z = [math.exp(i) for i in z]
    sum_exp_z = sum(exp_z)
    return [i / sum_exp_z for i in exp_z]

# Clase para manejar vectores
class MiVector:
    def __init__(self, datos):
        self.datos = datos

    def __add__(self, otro):
        return MiVector([x + y for x, y in zip(self.datos, otro.datos)])

    def __mul__(self, otro):
        return MiVector([x * y for x, y in zip(self.datos, otro.datos)])

    def suma(self):
        return sum(self.datos)

    def dot(self, otro):
        return sum(x * y for x, y in zip(self.datos, otro.datos))

# Función para calcular el logaritmo natural mediante la serie de Taylor
def ln_taylor(x, n_terms=100):
    if x <= 0:
        raise ValueError("El logaritmo natural no está definido para valores no positivos.")
    if x == 1:
        return 0

    num = x - 1
    denom = x + 1
    y = num / denom

    ln_approx = 0
    for n in range(n_terms):
        term = (2 / (2 * n + 1)) * (y ** (2 * n + 1))
        ln_approx += term

    return 2 * ln_approx

# Función para calcular el logaritmo en base 10 usando el logaritmo natural
def log10_taylor(x):
    ln_10 = ln_taylor(10)
    ln_x = ln_taylor(x)
    return ln_x / ln_10

# Clase de la Red Neuronal con una capa oculta
class RedNeuronal:
    def __init__(self, tasa_aprendizaje):
        self.tasa_aprendizaje = tasa_aprendizaje
        self.aleatorio = MiRandom(123)
        
        # Pesos para la capa oculta (5 neuronas)
        self.pesos_oculta = [MiVector([0.1 * self.aleatorio_value(), -0.2 * self.aleatorio_value(), 0.3 * self.aleatorio_value(), -0.4 * self.aleatorio_value()]) for _ in range(5)]
        self.sesgos_oculta = [0.1 * self.aleatorio_value() for _ in range(5)]
        
        # Pesos para la capa de salida (3 clases en Iris: versicolor, setosa, virginica)
        self.pesos_salida = [MiVector([0.1 * self.aleatorio_value(), -0.2 * self.aleatorio_value(), 0.3 * self.aleatorio_value(), -0.4 * self.aleatorio_value(), 0.5]) for _ in range(3)]
        self.sesgos_salida = [0.1 * self.aleatorio_value() for _ in range(3)]

    def aleatorio_value(self):
        return (self.aleatorio.randint(0, 100) - 50) / 100.0

    def entrenar(self, entradas, salidas_esperadas, epocas):
        for epoca in range(epocas):
            total_loss = 0
            for x, y_esperado in zip(entradas, salidas_esperadas):
                # Capa de entrada
                x_vec = MiVector(x)
                
                # Capa oculta
                z_oculta = [x_vec.dot(self.pesos_oculta[i]) + self.sesgos_oculta[i] for i in range(5)]
                a_oculta = [sigmoid(z) for z in z_oculta]
                
                # Capa de salida
                z_salida = [MiVector(a_oculta).dot(self.pesos_salida[i]) + self.sesgos_salida[i] for i in range(3)]
                y_predicho = softmax(z_salida)
                
                # Calcular la pérdida (entropía cruzada)
                loss = -sum(y_esperado[i] * math.log(y_predicho[i] + 1e-9) for i in range(3))
                total_loss += loss
                
                # Retropropagación y actualización de pesos y sesgos
                delta_salida = [y_predicho[i] - y_esperado[i] for i in range(3)]
                
                # Gradientes para la capa de salida
                gradientes_salida = [MiVector([a_oculta[j] * delta_salida[i] for j in range(len(a_oculta))]) for i in range(3)]

                
                # Actualizar pesos y sesgos de la capa de salida
                for i in range(3):
                    self.pesos_salida[i] = self.pesos_salida[i] - MiVector(gradientes_salida[i]) * self.tasa_aprendizaje
                    self.sesgos_salida[i] = self.sesgos_salida[i] - delta_salida[i] * self.tasa_aprendizaje
                
                # Gradientes para la capa oculta
                delta_oculta = [MiVector([self.pesos_salida[i].datos[j] * delta_salida[i] for i in range(3)]).dot(MiVector([a_oculta[j] * (1 - a_oculta[j]) * self.pesos_oculta[j].datos[k] for j in range(5)])) for k in range(5)]
                
                # Actualizar pesos y sesgos de la capa oculta
                for i in range(5):
                    self.pesos_oculta[i] = self.pesos_oculta[i] - x_vec * delta_oculta[i] * self.tasa_aprendizaje
                    self.sesgos_oculta[i] = self.sesgos_oculta[i] - delta_oculta[i] * self.tasa_aprendizaje
            
            # Imprimir la pérdida en cada época
            if epoca % 100 == 0:
                print(f"época {epoca + 1}/{epocas}, pérdida: {total_loss / len(entradas):.4f}")

    def predecir(self, x):
        # Capa de entrada
        x_vec = MiVector(x)
        
        # Capa oculta
        z_oculta = [x_vec.dot(self.pesos_oculta[i]) + self.sesgos_oculta[i] for i in range(5)]
        a_oculta = [sigmoid(z) for z in z_oculta]
        
        # Capa de salida
        z_salida = [MiVector(a_oculta).dot(self.pesos_salida[i]) + self.sesgos_salida[i] for i in range(3)]
        y_predicho = softmax(z_salida)
        
        return y_predicho

if __name__ == "__main__":
    # Datos de entrenamiento (con todas las características)
    entradas = [
        [5.1, 3.5, 1.4, 0.2],  # Iris-setosa
        [4.9, 3.0, 1.4, 0.2],  # Iris-setosa
        [6.2, 3.4, 5.4, 2.3],  # Iris-virginica
        [5.9, 3.0, 5.1, 1.8],  # Iris-virginica
        [7.0, 3.2, 4.7, 1.4],  # Iris-versicolor
        [6.4, 3.2, 4.5, 1.5]   # Iris-versicolor
    ]
    salidas = [
        [1, 0, 0],  # Iris-setosa
        [1, 0, 0],  # Iris-setosa
        [0, 0, 1],  # Iris-virginica
        [0, 0, 1],  # Iris-virginica
        [0, 1, 0],  # Iris-versicolor
        [0, 1, 0]   # Iris-versicolor
    ]
    
    red = RedNeuronal(tasa_aprendizaje=0.2)  # Tasa de aprendizaje
    red.entrenar(entradas, salidas, epocas=2000)  # Número de épocas

    # Prueba de predicción
    nuevas_entradas = [
        [4.8, 3.4, 1.6, 0.2],    # Iris-setosa
        [7.0, 3.2, 4.7, 1.4],    # Iris-versicolor
        [6.8, 3.0, 5.5, 2.1]     # Iris-virginica
    ]
    
    print("Predicciones:")
    for entrada in nuevas_entradas:
        prediccion = red.predecir(entrada)
        clases = ["Iris-setosa", "Iris-versicolor", "Iris-virginica"]
        clase_predicha = clases[prediccion.index(max(prediccion))]
        print(f"Entrada: {entrada} -> Predicción: {clase_predicha}")
