import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt

# Especificar la ruta al archivo CSV
archivo_csv = 'winequality-red.csv'

# Cargar el archivo CSV en un df de pandas
df = pd.read_csv(archivo_csv, delimiter=',')

# Mostrar las 10 primeras filas del DataFrame para verificar que se haya cargado correctamente
print(df.head(10))

# la columna 'quality' es nuestro objetivo y el resto son caracteristicas
X = df.drop('quality', axis=1)  # caracteristicas
y = df['quality']  # objetivo

# Dividir los datos en conjunto de entrenamiento y conjunto de prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Inicializar el clasificador de arbol de decision
clf = DecisionTreeClassifier(random_state=42)

# Entrenar el modelo
clf.fit(X_train, y_train)

# Obtener la precision en el conjunto de prueba 
accuracy = clf.score(X_test, y_test)
print(f'Precisión del arbol de decision: {accuracy:.2f}')

# Graficar el arbol de decision
plt.figure(figsize=(15, 10))
plot_tree(clf, filled=True, feature_names=X.columns, class_names=True, rounded=True)
plt.title("Árbol de Decisión para Predicción de Calidad de Vino")
plt.show()
